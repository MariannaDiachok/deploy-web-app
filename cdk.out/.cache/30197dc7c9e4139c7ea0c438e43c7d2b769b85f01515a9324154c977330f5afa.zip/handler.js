"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
async function main() {
    return {
        body: JSON.stringify({ message: 'Hello from Lambda 🎉' }),
        statusCode: 200,
    };
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQU8sS0FBSyxVQUFVLElBQUk7SUFDdEIsT0FBTztRQUNMLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUMsT0FBTyxFQUFFLHNCQUFzQixFQUFDLENBQUM7UUFDdkQsVUFBVSxFQUFFLEdBQUc7S0FDaEIsQ0FBQztBQUNKLENBQUM7QUFMSCxvQkFLRyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYWluKCkge1xuICAgIHJldHVybiB7XG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7bWVzc2FnZTogJ0hlbGxvIGZyb20gTGFtYmRhIPCfjoknfSksXG4gICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgfTtcbiAgfVxuICAiXX0=